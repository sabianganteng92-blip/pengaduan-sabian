package com.example.pengaduan_sekolah

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
