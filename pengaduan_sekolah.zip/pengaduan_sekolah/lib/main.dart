
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String baseUrl = 'http://127.0.0.1:8000/api';

void main() {
  runApp(const PengaduanApp());
}

class PengaduanApp extends StatelessWidget {
  const PengaduanApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Pengaduan Sekolah',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;

  Future<void> login() async {
    setState(() => loading = true);

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/login'),
        headers: {'Accept': 'application/json'},
        body: {'email': email.text.trim(), 'password': password.text},
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 && data['token'] != null) {
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => HomePage(token: data['token']),
          ),
        );
      } else {
        showMessage(data['message'] ?? 'Login gagal');
      }
    } catch (e) {
      showMessage('Tidak dapat terhubung ke Laravel. Periksa server API.');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEAF7F5),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Card(
            elevation: 5,
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.apartment, size: 65, color: Colors.teal),
                  const SizedBox(height: 12),
                  const Text(
                    'Pengaduan Sarana Sekolah',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text('Masuk untuk menyampaikan laporan'),
                  const SizedBox(height: 24),
                  TextField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'Email',
                      prefixIcon: Icon(Icons.email_outlined),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: password,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Password',
                      prefixIcon: Icon(Icons.lock_outline),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: loading ? null : login,
                      child: Text(loading ? 'Memproses...' : 'LOGIN'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final String token;

  const HomePage({super.key, required this.token});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List reports = [];
  bool loading = true;

  Map<String, String> get headers => {
        'Accept': 'application/json',
        'Authorization': 'Bearer ${widget.token}',
      };

  @override
  void initState() {
    super.initState();
    loadReports();
  }

  Future<void> loadReports() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/pengaduan'),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            reports = data is List ? data : (data['data'] ?? []);
          });
        }
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal memuat pengaduan')),
        );
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> addReport(
      String judul, String lokasi, String deskripsi) async {
    final response = await http.post(
      Uri.parse('$baseUrl/pengaduan'),
      headers: headers,
      body: {
        'judul': judul,
        'lokasi': lokasi,
        'deskripsi': deskripsi,
      },
    );

    if (response.statusCode >= 200 && response.statusCode < 300) {
      await loadReports();
    } else {
      throw Exception(response.body);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Pengaduan'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            tooltip: 'Muat ulang',
            onPressed: () {
              setState(() => loading = true);
              loadReports();
            },
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : reports.isEmpty
              ? const Center(child: Text('Belum ada pengaduan.'))
              : RefreshIndicator(
                  onRefresh: loadReports,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: reports.length,
                    itemBuilder: (context, index) {
                      final item = reports[index];
                      return Card(
                        child: ListTile(
                          leading: const CircleAvatar(
                            child: Icon(Icons.build_outlined),
                          ),
                          title: Text(
                            item['judul']?.toString() ?? 'Tanpa judul',
                          ),
                          subtitle: Text(
                            '${item['lokasi'] ?? '-'}\n'
                            '${item['deskripsi'] ?? ''}',
                          ),
                          isThreeLine: true,
                        ),
                      );
                    },
                  ),
                ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final result = await Navigator.push<Map<String, String>>(
            context,
            MaterialPageRoute(builder: (_) => const AddReportPage()),
          );

          if (result != null) {
            try {
              await addReport(
                result['judul']!,
                result['lokasi']!,
                result['deskripsi']!,
              );
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Pengaduan berhasil dikirim')),
                );
              }
            } catch (e) {
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Gagal mengirim pengaduan: $e')),
                );
              }
            }
          }
        },
        icon: const Icon(Icons.add),
        label: const Text('Buat Pengaduan'),
      ),
    );
  }
}

class AddReportPage extends StatefulWidget {
  const AddReportPage({super.key});

  @override
  State<AddReportPage> createState() => _AddReportPageState();
}

class _AddReportPageState extends State<AddReportPage> {
  final judul = TextEditingController();
  final lokasi = TextEditingController();
  final deskripsi = TextEditingController();

  @override
  void dispose() {
    judul.dispose();
    lokasi.dispose();
    deskripsi.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Buat Pengaduan')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(
            controller: judul,
            decoration: const InputDecoration(
              labelText: 'Judul pengaduan',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: lokasi,
            decoration: const InputDecoration(
              labelText: 'Lokasi sarana',
              hintText: 'Contoh: Ruang kelas XII RPL C',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: deskripsi,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'Deskripsi kerusakan',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: () {
              if (judul.text.trim().isEmpty ||
                  lokasi.text.trim().isEmpty ||
                  deskripsi.text.trim().isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Semua kolom harus diisi')),
                );
                return;
              }

              Navigator.pop(context, {
                'judul': judul.text.trim(),
                'lokasi': lokasi.text.trim(),
                'deskripsi': deskripsi.text.trim(),
              });
            },
            icon: const Icon(Icons.send),
            label: const Text('Kirim Pengaduan'),
          ),
        ],
      ),
    );
  }
}
